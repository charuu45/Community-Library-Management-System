package com.library.dao;

import com.library.model.Book;
import com.library.model.Member;
import com.library.model.Transaction;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

// Facade over the DAO classes. GUI code calls these methods only —
// it never talks to BookDAO/MemberDAO/TransactionDAO/AdminDAO directly.
public class LibraryStore {
    private static final int LOAN_DAYS = 14;
    private static final double FINE_PER_DAY = 5.0;

    private static final BookDAO bookDAO = new BookDAO();
    private static final MemberDAO memberDAO = new MemberDAO();
    private static final TransactionDAO txnDAO = new TransactionDAO();
    private static final AdminDAO adminDAO = new AdminDAO();

    public static List<Book> getBooks() { return bookDAO.getAllBooks(); }
    public static Book findBook(int id) { return bookDAO.findById(id); }
    public static void addBook(Book b) { bookDAO.addBook(b); }
    public static void removeBook(int id) { bookDAO.removeBook(id); }

    public static List<Member> getMembers() { return memberDAO.getAllMembers(); }
    public static Member findMemberByCredentials(String email, String password) {
        return memberDAO.findByCredentials(email, password);
    }

    public static boolean adminLogin(String username, String password) {
        return adminDAO.login(username, password);
    }

    public static List<Transaction> getTransactions() { return txnDAO.getAllTransactions(); }
    public static List<Transaction> getTransactionsForMember(int memberId) {
        return txnDAO.getTransactionsForMember(memberId);
    }
    public static List<Transaction> getOverdueTransactions() { return txnDAO.getOverdueTransactions(); }

    // Returns the due date on success, or null if the book isn't available.
    public static LocalDate issueBook(int bookId, int memberId) {
        Book book = bookDAO.findById(bookId);
        if (book == null || !book.isAvailable()) return null;

        LocalDate today = LocalDate.now();
        LocalDate dueDate = today.plusDays(LOAN_DAYS);
        Transaction t = new Transaction(0, bookId, memberId, today, dueDate);
        txnDAO.insertTransaction(t);
        bookDAO.changeAvailableCopies(bookId, -1);
        return dueDate;
    }

    // Returns the fine amount on success, or -1 if there's no active transaction for this book.
    public static double returnBook(int bookId) {
        Transaction active = txnDAO.findActiveTransactionForBook(bookId);
        if (active == null) return -1;

        LocalDate today = LocalDate.now();
        long lateDays = ChronoUnit.DAYS.between(active.getDueDate(), today);
        double fine = lateDays > 0 ? lateDays * FINE_PER_DAY : 0;

        txnDAO.completeReturn(active.getId(), today, fine);
        bookDAO.changeAvailableCopies(bookId, 1);
        return fine;
    }
}
