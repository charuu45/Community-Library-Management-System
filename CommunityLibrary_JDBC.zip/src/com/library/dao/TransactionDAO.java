package com.library.dao;

import com.library.model.Transaction;
import com.library.util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO {

    public List<Transaction> getAllTransactions() {
        return runQuery("SELECT * FROM transactions", null);
    }

    public List<Transaction> getTransactionsForMember(int memberId) {
        return runQuery("SELECT * FROM transactions WHERE member_id = ?", memberId);
    }

    public List<Transaction> getOverdueTransactions() {
        String sql = "SELECT * FROM transactions WHERE return_date IS NULL AND due_date < CURDATE()";
        return runQuery(sql, null);
    }

    private List<Transaction> runQuery(String sql, Integer param) {
        List<Transaction> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            if (param != null) ps.setInt(1, param);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public Transaction findActiveTransactionForBook(int bookId) {
        String sql = "SELECT * FROM transactions WHERE book_id = ? AND return_date IS NULL";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, bookId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void insertTransaction(Transaction t) {
        String sql = "INSERT INTO transactions (book_id, member_id, issue_date, due_date) VALUES (?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, t.getBookId());
            ps.setInt(2, t.getMemberId());
            ps.setDate(3, Date.valueOf(t.getIssueDate()));
            ps.setDate(4, Date.valueOf(t.getDueDate()));
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void completeReturn(int txnId, LocalDate returnDate, double fine) {
        String sql = "UPDATE transactions SET return_date = ?, fine = ? WHERE txn_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(returnDate));
            ps.setDouble(2, fine);
            ps.setInt(3, txnId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Transaction mapRow(ResultSet rs) throws SQLException {
        Transaction t = new Transaction(
                rs.getInt("txn_id"), rs.getInt("book_id"), rs.getInt("member_id"),
                rs.getDate("issue_date").toLocalDate(), rs.getDate("due_date").toLocalDate());
        Date ret = rs.getDate("return_date");
        if (ret != null) t.setReturnDate(ret.toLocalDate());
        t.setFine(rs.getDouble("fine"));
        return t;
    }
}
