package com.library.dao;

import com.library.model.Member;
import com.library.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MemberDAO {

    public Member findByCredentials(String email, String password) {
        String sql = "SELECT * FROM members WHERE email = ? AND password = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Member(rs.getInt("member_id"), rs.getString("name"),
                            rs.getString("email"), rs.getString("password"), rs.getString("member_type"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Member> getAllMembers() {
        List<Member> list = new ArrayList<>();
        String sql = "SELECT * FROM members";
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Member(rs.getInt("member_id"), rs.getString("name"),
                        rs.getString("email"), rs.getString("password"), rs.getString("member_type")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
