package com.library.util;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

public class FileLogger {
    private static final String LOG_FILE = "transaction_log.txt";

    public static void log(String message) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(LOG_FILE, true))) {
            pw.println("[" + LocalDateTime.now() + "] " + message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
