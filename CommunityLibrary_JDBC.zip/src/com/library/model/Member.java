package com.library.model;

public class Member {
    private int id;
    private String name;
    private String email;
    private String password;
    private String type; // Student / Faculty

    public Member(int id, String name, String email, String password, String type) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
        this.type = type;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public String getType() { return type; }
}
