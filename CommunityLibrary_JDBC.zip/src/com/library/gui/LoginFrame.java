package com.library.gui;

import com.library.dao.LibraryStore;
import com.library.model.Member;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private JTextField userField;
    private JPasswordField passField;
    private JComboBox<String> roleBox;

    public LoginFrame() {
        setTitle("Community Library Management System - Login");
        setSize(380, 260);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel title = new JLabel("Community Library", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(title, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 1; gbc.gridx = 0;
        add(new JLabel("Role:"), gbc);
        roleBox = new JComboBox<>(new String[]{"Admin", "Member"});
        gbc.gridx = 1;
        add(roleBox, gbc);

        gbc.gridy = 2; gbc.gridx = 0;
        add(new JLabel("Email / Username:"), gbc);
        userField = new JTextField(15);
        gbc.gridx = 1;
        add(userField, gbc);

        gbc.gridy = 3; gbc.gridx = 0;
        add(new JLabel("Password:"), gbc);
        passField = new JPasswordField(15);
        gbc.gridx = 1;
        add(passField, gbc);

        JButton loginBtn = new JButton("Login");
        gbc.gridy = 4; gbc.gridx = 0; gbc.gridwidth = 2;
        add(loginBtn, gbc);

        loginBtn.addActionListener(e -> attemptLogin());
    }

    private void attemptLogin() {
        String role = (String) roleBox.getSelectedItem();
        String user = userField.getText().trim();
        String pass = new String(passField.getPassword());

        if (user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter both username and password.");
            return;
        }

        if ("Admin".equals(role)) {
            if (LibraryStore.adminLogin(user, pass)) {
                new AdminDashboard().setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid admin credentials.");
            }
        } else {
            Member m = LibraryStore.findMemberByCredentials(user, pass);
            if (m != null) {
                new MemberDashboard(m).setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid member credentials.");
            }
        }
    }
}
