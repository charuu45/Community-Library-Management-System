package com.library.gui;

import com.library.dao.LibraryStore;
import com.library.model.Transaction;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ReportsPanel extends JPanel {

    public ReportsPanel() {
        setLayout(new BorderLayout(10, 10));
        JButton exportBtn = new JButton("Export Overdue Report (overdue_report.txt)");
        JTextArea preview = new JTextArea();
        preview.setEditable(false);

        add(new JScrollPane(preview), BorderLayout.CENTER);
        add(exportBtn, BorderLayout.SOUTH);

        exportBtn.addActionListener(e -> {
            StringBuilder sb = new StringBuilder("Overdue Books Report\n---------------------\n");
            for (Transaction t : LibraryStore.getOverdueTransactions()) {
                sb.append("Book ID: ").append(t.getBookId())
                  .append(" | Member ID: ").append(t.getMemberId())
                  .append(" | Due: ").append(t.getDueDate()).append("\n");
            }
            try (PrintWriter pw = new PrintWriter(new FileWriter("overdue_report.txt"))) {
                pw.print(sb);
                preview.setText(sb.toString());
                JOptionPane.showMessageDialog(this, "Report exported to overdue_report.txt");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Failed to write report.");
            }
        });
    }
}
