package com.library.gui;

import com.library.dao.LibraryStore;
import com.library.model.Book;
import com.library.model.Member;
import com.library.model.Transaction;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class MemberDashboard extends JFrame {
    private final Member member;

    public MemberDashboard(Member member) {
        this.member = member;
        setTitle("Member Dashboard - " + member.getName());
        setSize(700, 450);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Search Books", buildSearchPanel());
        tabs.addTab("My Borrowed Books", buildBorrowedPanel());
        add(tabs);
    }

    private JPanel buildSearchPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"ID", "Title", "Author", "Category", "Available"}, 0);
        JTable table = new JTable(model);
        JTextField searchField = new JTextField();
        JButton searchBtn = new JButton("Search");

        JPanel top = new JPanel(new BorderLayout());
        top.add(searchField, BorderLayout.CENTER);
        top.add(searchBtn, BorderLayout.EAST);

        Runnable populate = () -> {
            model.setRowCount(0);
            String query = searchField.getText().trim().toLowerCase();
            for (Book b : LibraryStore.getBooks()) {
                if (query.isEmpty() || b.getTitle().toLowerCase().contains(query)
                        || b.getAuthor().toLowerCase().contains(query)) {
                    model.addRow(new Object[]{b.getId(), b.getTitle(), b.getAuthor(),
                            b.getCategory(), b.isAvailable() ? "Yes" : "No"});
                }
            }
        };
        searchBtn.addActionListener(e -> populate.run());
        populate.run();

        panel.add(top, BorderLayout.NORTH);
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }

    private JPanel buildBorrowedPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"Book ID", "Issue Date", "Due Date", "Returned"}, 0);
        JTable table = new JTable(model);

        for (Transaction t : LibraryStore.getTransactionsForMember(member.getId())) {
            model.addRow(new Object[]{t.getBookId(), t.getIssueDate(), t.getDueDate(),
                    t.getReturnDate() == null ? "No" : "Yes"});
        }
        panel.add(new JScrollPane(table), BorderLayout.CENTER);
        return panel;
    }
}
