package com.library.gui;

import com.library.dao.LibraryStore;
import com.library.util.FileLogger;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;

public class IssueReturnPanel extends JPanel {

    public IssueReturnPanel() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField bookIdField = new JTextField(8);
        JTextField memberIdField = new JTextField(8);
        JButton issueBtn = new JButton("Issue Book");
        JButton returnBtn = new JButton("Return Book");
        JTextArea resultArea = new JTextArea(6, 30);
        resultArea.setEditable(false);

        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Book ID:"), gbc);
        gbc.gridx = 1;
        add(bookIdField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("Member ID:"), gbc);
        gbc.gridx = 1;
        add(memberIdField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        add(issueBtn, gbc);
        gbc.gridx = 1;
        add(returnBtn, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        add(new JScrollPane(resultArea), gbc);

        issueBtn.addActionListener(e -> {
            try {
                int bookId = Integer.parseInt(bookIdField.getText().trim());
                int memberId = Integer.parseInt(memberIdField.getText().trim());
                LocalDate dueDate = LibraryStore.issueBook(bookId, memberId);
                if (dueDate == null) {
                    resultArea.setText("Book unavailable or not found.");
                    return;
                }
                FileLogger.log("ISSUE - Book:" + bookId + " Member:" + memberId + " Due:" + dueDate);
                resultArea.setText("Issued. Due date: " + dueDate);
            } catch (NumberFormatException ex) {
                resultArea.setText("Enter valid numeric IDs.");
            }
        });

        returnBtn.addActionListener(e -> {
            try {
                int bookId = Integer.parseInt(bookIdField.getText().trim());
                double fine = LibraryStore.returnBook(bookId);
                if (fine < 0) {
                    resultArea.setText("No active issue record for this book.");
                    return;
                }
                FileLogger.log("RETURN - Book:" + bookId + " Fine:" + fine);
                resultArea.setText("Returned. Fine: Rs." + fine);
            } catch (NumberFormatException ex) {
                resultArea.setText("Enter a valid numeric Book ID.");
            }
        });
    }
}
