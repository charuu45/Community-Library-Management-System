package com.library.gui;

import com.library.dao.LibraryStore;
import com.library.model.Book;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class BookManagementPanel extends JPanel {
    private DefaultTableModel tableModel;
    private JTable table;

    public BookManagementPanel() {
        setLayout(new BorderLayout(10, 10));

        tableModel = new DefaultTableModel(new String[]{"ID", "Title", "Author", "ISBN", "Category", "Available"}, 0);
        table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel formPanel = new JPanel(new GridLayout(2, 5, 5, 5));
        JTextField titleField = new JTextField();
        JTextField authorField = new JTextField();
        JTextField isbnField = new JTextField();
        JTextField categoryField = new JTextField();
        JButton addBtn = new JButton("Add Book");
        JButton deleteBtn = new JButton("Delete Selected");

        formPanel.add(new JLabel("Title"));
        formPanel.add(new JLabel("Author"));
        formPanel.add(new JLabel("ISBN"));
        formPanel.add(new JLabel("Category"));
        formPanel.add(new JLabel(""));
        formPanel.add(titleField);
        formPanel.add(authorField);
        formPanel.add(isbnField);
        formPanel.add(categoryField);
        formPanel.add(addBtn);

        add(formPanel, BorderLayout.NORTH);
        add(deleteBtn, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> {
            if (titleField.getText().isBlank() || authorField.getText().isBlank()) {
                JOptionPane.showMessageDialog(this, "Title and author are required.");
                return;
            }
            Book b = new Book(0, titleField.getText(), authorField.getText(),
                    isbnField.getText(), categoryField.getText(), true);
            LibraryStore.addBook(b);
            refreshTable();
            titleField.setText(""); authorField.setText("");
            isbnField.setText(""); categoryField.setText("");
        });

        deleteBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Select a book to delete.");
                return;
            }
            int id = (int) tableModel.getValueAt(row, 0);
            LibraryStore.removeBook(id);
            refreshTable();
        });

        refreshTable();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        for (Book b : LibraryStore.getBooks()) {
            tableModel.addRow(new Object[]{b.getId(), b.getTitle(), b.getAuthor(),
                    b.getIsbn(), b.getCategory(), b.isAvailable() ? "Yes" : "No"});
        }
    }
}
