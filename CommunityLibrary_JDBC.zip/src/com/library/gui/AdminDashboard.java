package com.library.gui;

import javax.swing.*;

public class AdminDashboard extends JFrame {

    public AdminDashboard() {
        setTitle("Admin Dashboard - Community Library");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Manage Books", new BookManagementPanel());
        tabs.addTab("Issue / Return", new IssueReturnPanel());
        tabs.addTab("Reports", new ReportsPanel());

        add(tabs);
    }
}
