-- Community Library Management System — Database Schema
-- MySQL 8.x

CREATE DATABASE IF NOT EXISTS community_library;
USE community_library;

-- ADMIN / LIBRARIAN
CREATE TABLE admin (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- MEMBERS
CREATE TABLE members (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    member_type ENUM('Student', 'Faculty', 'General') NOT NULL DEFAULT 'General',
    join_date DATE NOT NULL DEFAULT (CURRENT_DATE)
);

-- BOOKS
CREATE TABLE books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(150) NOT NULL,
    isbn VARCHAR(20) UNIQUE,
    category VARCHAR(50),
    total_copies INT NOT NULL DEFAULT 1,
    available_copies INT NOT NULL DEFAULT 1,
    CHECK (available_copies >= 0 AND available_copies <= total_copies)
);

-- TRANSACTIONS (issue / return records)
CREATE TABLE transactions (
    txn_id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    member_id INT NOT NULL,
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE DEFAULT NULL,
    fine DECIMAL(8,2) NOT NULL DEFAULT 0.00,
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE
);

-- RESERVATIONS (optional feature — reserve a currently-issued book)
CREATE TABLE reservations (
    reservation_id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    member_id INT NOT NULL,
    reserved_on DATE NOT NULL DEFAULT (CURRENT_DATE),
    status ENUM('Pending', 'Fulfilled', 'Cancelled') NOT NULL DEFAULT 'Pending',
    FOREIGN KEY (book_id) REFERENCES books(book_id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE
);

-- Indexes for common searches
CREATE INDEX idx_books_title ON books(title);
CREATE INDEX idx_books_author ON books(author);
CREATE INDEX idx_txn_member ON transactions(member_id);
CREATE INDEX idx_txn_active ON transactions(return_date);

-- Sample seed data
INSERT INTO admin (username, password) VALUES ('admin', 'admin123');

INSERT INTO members (name, email, password, member_type) VALUES
('Charu', 'charu@example.com', '1234', 'Student');

INSERT INTO books (title, author, isbn, category, total_copies, available_copies) VALUES
('Clean Code', 'Robert Martin', '9780132350884', 'Programming', 2, 2),
('1984', 'George Orwell', '9780451524935', 'Fiction', 1, 1);
